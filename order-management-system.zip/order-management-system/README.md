# Online Order Management System

A Spring Boot 3 + Java 17 REST API using the package style from your screenshot.

## Included packages
- config
- controller
- service
- service.impl
- repository
- entity
- dto.request
- dto.response
- security
- exception
- util

## Extra classes added
- Product, Order, OrderItem, CustomerAddress
- ProductController, OrderController
- ProductService, OrderService and implementations
- OrderStatus, PaymentStatus
- ResourceNotFoundException

## Main features
- JWT register/login
- Product management
- Customer order creation
- View my orders
- Admin order status updates
- H2 database for quick testing

## Default admin
- email: admin@example.com
- password: admin123

## Run
```bash
mvn spring-boot:run
```

## Key endpoints
- POST /api/auth/register
- POST /api/auth/login
- GET /api/users/me
- POST /api/products
- GET /api/products
- POST /api/orders
- GET /api/orders/my
- GET /api/orders
- PATCH /api/orders/{orderNumber}/status
```
Authorization: Bearer <token>
```
