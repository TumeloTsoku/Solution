package com.example.usermanagement.service.impl;

import com.example.usermanagement.dto.request.CreateOrderItemRequest;
import com.example.usermanagement.dto.request.CreateOrderRequest;
import com.example.usermanagement.dto.request.UpdateOrderStatusRequest;
import com.example.usermanagement.dto.response.OrderItemResponse;
import com.example.usermanagement.dto.response.OrderResponse;
import com.example.usermanagement.entity.*;
import com.example.usermanagement.exception.ResourceNotFoundException;
import com.example.usermanagement.exception.UnauthorizedException;
import com.example.usermanagement.repository.OrderRepository;
import com.example.usermanagement.repository.ProductRepository;
import com.example.usermanagement.service.OrderService;
import com.example.usermanagement.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    @Override
    @Transactional
    public OrderResponse createOrder(CreateOrderRequest request) {
        User currentUser = SecurityUtils.getCurrentUser();

        CustomerAddress address = CustomerAddress.builder()
                .user(currentUser)
                .street(request.getStreet())
                .city(request.getCity())
                .state(request.getState())
                .postalCode(request.getPostalCode())
                .country(request.getCountry())
                .build();

        Order order = Order.builder()
                .orderNumber("ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .user(currentUser)
                .shippingAddress(address)
                .status(OrderStatus.CREATED)
                .paymentStatus(PaymentStatus.PENDING)
                .totalAmount(BigDecimal.ZERO)
                .build();

        List<OrderItem> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (CreateOrderItemRequest itemRequest : request.getItems()) {
            Product product = productRepository.findById(itemRequest.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + itemRequest.getProductId()));

            if (product.getStockQuantity() < itemRequest.getQuantity()) {
                throw new IllegalArgumentException("Insufficient stock for product " + product.getName());
            }

            BigDecimal subtotal = product.getPrice().multiply(BigDecimal.valueOf(itemRequest.getQuantity()));
            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .product(product)
                    .quantity(itemRequest.getQuantity())
                    .unitPrice(product.getPrice())
                    .subtotal(subtotal)
                    .build();

            product.setStockQuantity(product.getStockQuantity() - itemRequest.getQuantity());
            items.add(orderItem);
            total = total.add(subtotal);
        }

        order.setItems(items);
        order.setTotalAmount(total);
        return map(orderRepository.save(order));
    }

    @Override
    public List<OrderResponse> getMyOrders() {
        User currentUser = SecurityUtils.getCurrentUser();
        return orderRepository.findByUserId(currentUser.getId()).stream().map(this::map).toList();
    }

    @Override
    public List<OrderResponse> getAllOrders() {
        User currentUser = SecurityUtils.getCurrentUser();
        if (currentUser.getRole() != Role.ROLE_ADMIN) {
            throw new UnauthorizedException("Only admins can view all orders");
        }
        return orderRepository.findAll().stream().map(this::map).toList();
    }

    @Override
    @Transactional
    public OrderResponse updateOrderStatus(String orderNumber, UpdateOrderStatusRequest request) {
        User currentUser = SecurityUtils.getCurrentUser();
        if (currentUser.getRole() != Role.ROLE_ADMIN) {
            throw new UnauthorizedException("Only admins can update order status");
        }

        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderNumber));
        order.setStatus(request.getStatus());
        order.setPaymentStatus(request.getPaymentStatus());
        return map(orderRepository.save(order));
    }

    private OrderResponse map(Order order) {
        return OrderResponse.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .customerEmail(order.getUser().getEmail())
                .status(order.getStatus().name())
                .paymentStatus(order.getPaymentStatus().name())
                .totalAmount(order.getTotalAmount())
                .createdAt(order.getCreatedAt())
                .shippingAddress(order.getShippingAddress().getStreet() + ", " + order.getShippingAddress().getCity() + ", "
                        + order.getShippingAddress().getState() + ", " + order.getShippingAddress().getPostalCode() + ", "
                        + order.getShippingAddress().getCountry())
                .items(order.getItems().stream().map(item -> OrderItemResponse.builder()
                        .productId(item.getProduct().getId())
                        .productName(item.getProduct().getName())
                        .quantity(item.getQuantity())
                        .unitPrice(item.getUnitPrice())
                        .subtotal(item.getSubtotal())
                        .build()).toList())
                .build();
    }
}
