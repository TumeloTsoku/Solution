package com.example.usermanagement.service;

import com.example.usermanagement.dto.response.UserResponse;

import java.util.List;

public interface UserService {
    List<UserResponse> getAllUsers();
    UserResponse getCurrentUser();
}
