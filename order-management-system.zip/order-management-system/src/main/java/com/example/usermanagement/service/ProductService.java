package com.example.usermanagement.service;

import com.example.usermanagement.dto.request.CreateProductRequest;
import com.example.usermanagement.dto.response.ProductResponse;

import java.util.List;

public interface ProductService {
    ProductResponse createProduct(CreateProductRequest request);
    List<ProductResponse> getAllProducts();
}
