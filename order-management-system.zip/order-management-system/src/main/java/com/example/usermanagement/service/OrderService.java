package com.example.usermanagement.service;

import com.example.usermanagement.dto.request.CreateOrderRequest;
import com.example.usermanagement.dto.request.UpdateOrderStatusRequest;
import com.example.usermanagement.dto.response.OrderResponse;

import java.util.List;

public interface OrderService {
    OrderResponse createOrder(CreateOrderRequest request);
    List<OrderResponse> getMyOrders();
    List<OrderResponse> getAllOrders();
    OrderResponse updateOrderStatus(String orderNumber, UpdateOrderStatusRequest request);
}
