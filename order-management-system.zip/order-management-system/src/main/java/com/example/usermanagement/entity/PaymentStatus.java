package com.example.usermanagement.entity;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED
}
