package com.example.usermanagement.dto.request;

import com.example.usermanagement.entity.OrderStatus;
import com.example.usermanagement.entity.PaymentStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateOrderStatusRequest {
    @NotNull
    private OrderStatus status;
    @NotNull
    private PaymentStatus paymentStatus;
}
