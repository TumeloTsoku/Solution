package com.example.usermanagement.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreateProductRequest {
    @NotBlank
    private String name;
    @NotBlank
    private String sku;
    private String description;
    @NotNull @DecimalMin("0.0")
    private BigDecimal price;
    @NotNull @Min(0)
    private Integer stockQuantity;
}
