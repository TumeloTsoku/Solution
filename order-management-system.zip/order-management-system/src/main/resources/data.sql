INSERT INTO users (id, full_name, email, password, role, enabled, created_at)
VALUES (1, 'Admin User', 'admin@example.com', '$2a$10$7aLJmA2q3O7P2HfRLh4WfudeiW6riw37ht4H59sj2CCOrGXSInx1e', 'ROLE_ADMIN', true, CURRENT_TIMESTAMP());
