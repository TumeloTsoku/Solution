package com.fnb.ordermanagementservice.controller;

import com.fnb.ordermanagementservice.dto.request.LoginRequest;
import com.fnb.ordermanagementservice.dto.request.RegisterRequest;
import com.fnb.ordermanagementservice.dto.response.LoginResponse;
import com.fnb.ordermanagementservice.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService service;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterRequest request) {
        return ResponseEntity.ok(service.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(service.login(request));
    }
}