package com.fnb.ordermanagementservice.service.impl;

import com.fnb.ordermanagementservice.dto.request.LoginRequest;
import com.fnb.ordermanagementservice.dto.request.RegisterRequest;
import com.fnb.ordermanagementservice.dto.response.LoginResponse;
import com.fnb.ordermanagementservice.model.User;
import com.fnb.ordermanagementservice.repository.UserRepository;
import com.fnb.ordermanagementservice.security.JwtUtil;
import com.fnb.ordermanagementservice.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository repo;
    private final PasswordEncoder encoder;
    private final AuthenticationManager manager;
    private final JwtUtil jwtUtil;

    @Override
    public String register(RegisterRequest request) {

        if (repo.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(encoder.encode(request.getPassword()))
                .build();

        repo.save(user);
        return "Registered successfully";
    }

    @Override
    public LoginResponse login(LoginRequest request) {

        manager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        String token = jwtUtil.generateToken(request.getEmail());
        return new LoginResponse(token);
    }
}