package com.fnb.ordermanagementservice.service;

import com.fnb.ordermanagementservice.dto.request.LoginRequest;
import com.fnb.ordermanagementservice.dto.request.RegisterRequest;
import com.fnb.ordermanagementservice.dto.response.LoginResponse;

public interface UserService {

    String register(RegisterRequest request);

    LoginResponse login(LoginRequest request);
}